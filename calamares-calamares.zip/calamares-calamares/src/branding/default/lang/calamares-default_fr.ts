<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr">
<context>
    <name>show</name>
    <message>
        <location filename="../show.qml" line="64"/>
        <source>This is a second Slide element.</source>
        <translation>Ceci est la deuxieme affiche.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="68"/>
        <source>This is a third Slide element.</source>
        <translation>La troisième affice ce trouve ici.</translation>
    </message>
</context>
</TS>
